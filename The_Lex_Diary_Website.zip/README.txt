THE LEX DIARY — QUICK SETUP

1. Open index.html in your browser.
2. Put your own photos inside the "images" folder.
3. Rename your photos to:
   hero.jpg
   current.jpg
   love.jpg
   friends.jpg
   style.jpg
   motherhood.jpg
   advice.jpg

4. Open index.html again. Your photos will appear automatically.

You can also change any text directly inside index.html.
No framework, app, or installation is required.
